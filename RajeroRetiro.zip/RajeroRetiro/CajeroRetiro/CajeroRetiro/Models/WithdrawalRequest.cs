﻿namespace CajeroRetiro.Models
{
    public class WithdrawalRequest
    {
        public int Amount { get; set; } // Monto solicitado
        public string DispenseMode { get; set; } // Modo de dispensación

        public int Bills100 { get; set; }
        public int Bills200 { get; set; }
        public int Bills500 { get; set; }
        public int Bills1000 { get; set; }
    }
}
