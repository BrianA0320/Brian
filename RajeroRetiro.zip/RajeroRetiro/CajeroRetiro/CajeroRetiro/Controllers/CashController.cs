﻿using CajeroRetiro.Models;
using Microsoft.AspNetCore.Mvc;

namespace CajeroRetiro.Controllers
{
    public class CashController : Controller
    {
        // Acción para la vista de configuración del modo de dispensación
        public IActionResult Configure()
        {
            // Recuperar el modo de dispensación desde la sesión
            var dispenseMode = HttpContext.Session.GetString("DispenseMode") ?? "Eficiente"; // Valor por defecto si no hay sesión

            // Pasar el modo seleccionado a la vista
            ViewBag.SelectedMode = dispenseMode;
            return View();
        }

        // Acción para cambiar el modo de dispensación
        [HttpPost]
        public IActionResult Configure(string selectedMode)
        {
            // Guardar el modo seleccionado en sesión
            HttpContext.Session.SetString("DispenseMode", selectedMode);

            // Actualizar la vista con el modo seleccionado
            ViewBag.SelectedMode = selectedMode;
            return View();
        }

        // Acción para mostrar la vista de retiro
        public IActionResult Withdraw()
        {
            return View();
        }

        // Acción para procesar el retiro
        [HttpPost]
        public IActionResult Withdraw(WithdrawalRequest request)
        {
            // Recuperar el modo de dispensación desde la sesión
            var dispenseMode = HttpContext.Session.GetString("DispenseMode") ?? "Eficiente"; // Valor por defecto si no hay sesión

            // Validar monto según el modo de dispensación
            if (!IsValidAmount(request.Amount, dispenseMode))
            {
                ModelState.AddModelError("", "Monto no válido para el modo de dispensación seleccionado.");
                return View(request);
            }

            // Calcular las denominaciones de billetes
            CalculateBills(request, dispenseMode);

            // Mostrar resultado
            return View("Result", request);
        }

        // Método para validar si el monto es válido según el modo
        private bool IsValidAmount(int amount, string dispenseMode)
        {
            var validAmounts = dispenseMode switch
            {
                "Solo 200 y 1000" => amount % 200 == 0 && amount >= 200,
                "Solo 100 y 500" => amount % 100 == 0 && amount >= 100,
                "Eficiente" => amount % 100 == 0 && amount >= 100,
                _ => false
            };
            return validAmounts;
        }

        // Método para calcular la cantidad de billetes
        private void CalculateBills(WithdrawalRequest request, string dispenseMode)
        {
            int[] denominations = dispenseMode switch
            {
                "Solo 200 y 1000" => new int[] { 1000, 200 },
                "Solo 100 y 500" => new int[] { 500, 100 },
                "Eficiente" => new int[] { 1000, 500, 200, 100 },
                _ => throw new InvalidOperationException("Modo de dispensación no válido")
            };

            int amountLeft = request.Amount;

            foreach (var bill in denominations)
            {
                int billCount = amountLeft / bill;
                amountLeft %= bill;

                switch (bill)
                {
                    case 100:
                        request.Bills100 = billCount;
                        break;
                    case 200:
                        request.Bills200 = billCount;
                        break;
                    case 500:
                        request.Bills500 = billCount;
                        break;
                    case 1000:
                        request.Bills1000 = billCount;
                        break;
                }
            }
        }
    }
}

